/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package molkarin;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;


/**
 *
 * @author Parakash
 */
public class ValidationClass {
    public static boolean isWord(String input)
    {
        return Pattern.matches("[a-zA-Z]+",input);
    }
    public static boolean isID(String input)
    {
        int value = 0;
        try
        {
            value=Integer.parseInt(input);
            return Pattern.matches("[0-9]{5}",input);
        }
        catch(NumberFormatException e)
        {
            //JOptionPane.showMessageDialog(null, "ID must contains 5 digits"); not showing this statement
            //System.out.println("Number format exception");
            return false;
        }
       
       
    }
    public static boolean isCode(String input)
    {
        return Pattern.matches("[A-Z]{4}",input);
    }
    public static boolean isAge(String input) //  is same as experice 30 years : 360 months
    {
        return Pattern.matches("[0-9]{1,3}",input);
    }
    public static boolean isRatings(String input) //  is same as experice 30 years : 360 months
    {
        return Pattern.matches("[0-5]{1}",input);
    }
    public static boolean isEmail(String input)
    {
        String emailRegex="^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";//^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z](2,6)$
        Pattern pat = Pattern.compile(emailRegex);
        if(input == null)
        {
            return false;
        }
        return pat.matcher(input).matches();
    }
    public static boolean isPass(String input)
    {
        String PassRegex="((?=.*[a-z])(?=.*\\d)(?=.*[A-Z])(?=.*[@#$%!]).{8,40})";
        Pattern PassPat = Pattern.compile(PassRegex);
        Matcher matcher = PassPat.matcher(input);
        return matcher.matches();
    }
    public static boolean isNumber(String input)
    {
        Pattern p = Pattern.compile("(0/91)?[7-9][0-9]{9}");
        Matcher m = p.matcher(input);
        return (m.find() && m.group().equals(input));
    }
    public static boolean isTime(String input)
    {
        Pattern p = Pattern.compile("(1[012]|[1-9]):[0-5][0-9](\\s)?(?i)(am|pm)");
        Matcher m = p.matcher(input);
        return m.matches();
        
    }
}
