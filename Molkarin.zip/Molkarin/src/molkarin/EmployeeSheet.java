/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package molkarin;

/**
 *
 * @author Parakash
 */
public class EmployeeSheet {
    private int ID,Age,Experience_In_Months,Mobile_No,Aadhar_No,Ratings_Star;
    private String Last_Name,First_Name,Middle_Name,Gender,Service,Status,PAN_No,Address,Comment;
    public EmployeeSheet(int ID, String Last_Name, String First_Name, String Middle_Name, String Gender, int Age, String Service, String Status, int Experience_In_Months, int Mobile_No, int Aadhar_No, String PAN_No, String Address, int Ratings_Star, String Comment)
    {
        this.ID=ID;
        this.Last_Name=Last_Name;
        this.First_Name=First_Name;
        this.Middle_Name=Middle_Name;
        this.Gender=Gender;
        this.Age=Age;
        this.Service=Service;
        this.Status=Status;
        this.Experience_In_Months=Experience_In_Months;
        this.Mobile_No=Mobile_No;
        this.Aadhar_No=Aadhar_No;
        this.PAN_No=PAN_No;
        this.Address=Address;
        this.Ratings_Star=Ratings_Star;
        this.Comment=Comment;
    }
    public EmployeeSheet(int ID, String Last_Name, String First_Name, String Middle_Name, String Gender, int Age, int Experience_In_Months, int Ratings_Star)
    {
        this.ID=ID;
        this.Last_Name=Last_Name;
        this.First_Name=First_Name;
        this.Middle_Name=Middle_Name;
        this.Gender=Gender;
        this.Age=Age;
        this.Experience_In_Months=Experience_In_Months;
        this.Ratings_Star = Ratings_Star;
        
    }
    public int getID()
    {
        return ID;
    }
    public String getLast_Name()
    {
        return Last_Name;
    }
    public String getFirst_Name()
    {
        return First_Name;
    }
    public String getMiddle_Name()
    {
        return Middle_Name;
    }
    public String getGender()
    {
        return Gender;
    }
    public int getAge()
    {
        return Age;
    }
    public String getService()
    {
        return Service;
    }
    public String getStatus()
    {
        return Status;
    }
    public int getExperience_In_Months()
    {
        return Experience_In_Months;
    }
    public int getMobile_No()
    {
        return Mobile_No;
    }
    public int getAadhar_No()
    {
        return Aadhar_No;
    }
    public String getPAN_No()
    {
        return PAN_No;
    }
    public String getAddress()
    {
        return Address;
    }
    public int getRatings_Star()
    {
        return Ratings_Star;
    }
    public String getComment()
    {
        return Comment;
    }
}
