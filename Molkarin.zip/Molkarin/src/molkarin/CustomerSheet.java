/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package molkarin;

/**
 *
 * @author Parakash
 */
public class CustomerSheet {
    private String C_Last_Name,C_First_Name,C_Middle_Name,C_Email,C_Pass,C_Mobile_No,C_Maid,C_Maid_Payment,C_Area,C_Address,C_Cook,C_Cook_Payment,C_Nurse,C_Nurse_Payment,C_PatientCare,C_PatientCare_Payment;
    
    public CustomerSheet(String C_Last_Name,String C_First_Name,String C_Middle_Name,String C_Email,String C_Pass,String C_Mobile_No,String C_Maid,String C_Maid_Payment,String C_Area,String C_Address,String C_Cook,String C_Cook_Payment,String C_Nurse,String C_Nurse_Payment,String C_PatientCare,String C_PatientCare_Payment)
    {
        this.C_Last_Name=C_Last_Name;
        this.C_First_Name=C_First_Name;
        this.C_Middle_Name=C_Middle_Name;
        this.C_Email=C_Email;
        this.C_Pass=C_Pass;
        this.C_Mobile_No=C_Mobile_No;
        this.C_Maid=C_Maid;
        this.C_Maid_Payment=C_Maid_Payment;
        this.C_Area=C_Area;
        this.C_Address=C_Address;
        this.C_Cook=C_Cook;
        this.C_Cook_Payment=C_Cook_Payment;
        this.C_Nurse=C_Nurse;
        this.C_Nurse_Payment=C_Nurse_Payment;
        this.C_PatientCare=C_PatientCare;
        this.C_PatientCare_Payment=C_PatientCare_Payment;
        
    }
    public CustomerSheet(String C_Maid,String C_Maid_Payment,String C_Cook,String C_Cook_Payment,String C_Nurse,String C_Nurse_Payment,String C_PatientCare,String C_PatientCare_Payment)
    {
        this.C_Maid=C_Maid;
        this.C_Maid_Payment=C_Maid_Payment;
        this.C_Cook=C_Cook;
        this.C_Cook_Payment=C_Cook_Payment;
        this.C_Nurse=C_Nurse;
        this.C_Nurse_Payment=C_Nurse_Payment;
        this.C_PatientCare=C_PatientCare;
        this.C_PatientCare_Payment=C_PatientCare_Payment;
    }
    public String getLastName()
    {
        return C_Last_Name;
    }
    public String getFirstName()
    {
        return C_First_Name;
    }
    public String getMiddleName()
    {
        return C_Middle_Name;
    }
    public String getEmail()
    {
        return C_Email;
    }
    public String getPass()
    {
        return C_Pass;
    }
    public String getMobileNo()
    {
        return C_Mobile_No;
    }
    public String getMaid()
    {
        return C_Maid;
    }
    public String getMaidPayment()
    {
        return C_Maid_Payment;
    }
    public String getArea()
    {
        return C_Area;
    }
    public String getAddress()
    {
        return C_Address;
    }
    public String getCook()
    {
        return C_Cook;
    }
    public String getCookPayment()
    {
        return C_Cook_Payment;
    }
    public String getNurse()
    {
        return C_Nurse;
    }
    public String getNursePayment()
    {
        return C_Nurse_Payment;
    }
    public String getPatientCare()
    {
        return C_PatientCare;
    }
    public String getPatientCarePayment()
    {
        return C_PatientCare_Payment;
    }
}
