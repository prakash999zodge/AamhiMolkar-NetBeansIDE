/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package molkarin;
import java.io.*;
import java.lang.*;
import java.util.Scanner;
/**
 *
 * @author Parakash
 */
public class HandleNumberExc {
    public static int methodB(int dir)
    {
        int result = 12 / dir;
        return result;
    }
    public static void methodA(String s)
    {
        int value = 0;
        try
        {
            value=Integer.parseInt(s);
            System.out.println("Valid");
        }
        catch(NumberFormatException e)
        {
            System.out.println("Invalid : Number format exception");
            return;
        }
        try
        {
            System.out.println("Result is : "+methodB(value));
        }
        catch(ArithmeticException a)
        {
            System.out.println("Division by zero");
        }
    }
    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);
        String sc;
        System.out.println("Enter : ");
        sc = scan.next();
        methodA(sc);
    }
}
