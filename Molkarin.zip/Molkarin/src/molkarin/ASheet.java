/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package molkarin;

import java.util.regex.*;

/**
 *
 * @author Parakash
 */
class ASheet {
    private int Day;
    private String Status, Time_IN, Time_OUT, VCustomer, VMolkarin, Comment;
    
    
    
    
    
    public ASheet(int Day, String Status,String Time_IN,String Time_OUT,String VCustomer,String VMolkarin,String Comment)
    {
        this.Day=Day;
        this.Status=Status;
        this.Time_IN=Time_IN;
        this.Time_OUT=Time_OUT;
        this.VCustomer=VCustomer;
        this.VMolkarin=VMolkarin;
        this.Comment=Comment;
    }
    public int getDay()
    {
        return Day;
    }
    public String getStatus()
    {
        return Status;
    }
    public String getTime_IN()
    {
        return Time_IN;
    }
    public String getTime_OUT()
    {
        return Time_OUT;
    }
    public String getVCustomer()
    {
        return VCustomer;
    }
    public String getVMolkarin()
    {
        return VMolkarin;
    }
    public String getComment()
    {
        return Comment;
    }
}
